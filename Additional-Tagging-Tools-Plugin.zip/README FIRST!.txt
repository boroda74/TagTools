ADDING THE PLUGIN

1 – Download the appropriate ZIP file and unpack it to a temporary folder of your choice.
2 – Open MusicBee. From the menubar > Edit > Edit Preferences > Plugins > Add Plugin...
3 – Browse to the folder where you have unpacked the downloaded zip and open the file "mb_TagTools.zip" from this folder. Close the Preferences window.
4 – To configure plugin, open MusicBee. From the menubar > Edit > Edit Preferences> Plugins > Additional Tagging & Reporting Tools > Configure.

INSTALLING ADVANCED SEARCH & REPLACE PRESETS:
1 – Open MusicBee. From the menubar > Tools > Additional Tagging & Reporting Tools > Advanced Search & Replace > Click "Install All" to load all predefined presets.


UPDATING THE PLUGIN

1 – Download the appropriate ZIP file and unpack it to a temporary folder of your choice.

NOTE:
2a – If you are using the portable version of MusicBee, you can update the plugin only by copying  the file "mb_TagTools.dll" from the archive "mb_TagTools.zip" to "Plugins" folder in the MusicBee application folder, overwriting existing file. This will keep all ASR presets as is.

OTHERWISE:
2b – Open MusicBee. From the menubar > Edit > Edit Preferences > Plugins > Additional Tagging & Reporting Tools > Disable. Close and restart MusicBee.
3b – Open MusicBee. From the menubar > Edit > Edit Preferences > Plugins > Add Plugin... Browse to the folder where the updated file "mb_TagTools.zip" is located and open this file. Close preferences.

UPDATING THE ASR PRESETS:
1 – Open MusicBee. From the menubar > Tools > Additional Tagging & Reporting Tools > Advanced Search & Replace.
2a – Click the "Install All" button to install all predefined ASR presets. This installs all predefined presets and will update to the latest version any preset(s) that have already been installed.
OR
2b – Click the "Install New" button to (re)install predefined presets which were created or updated by the plugin developer since the last time you installed or updated them by either of two methods.

IMPORTANT NOTE: "Install New" will not reinstall any predefined presets deleted by you. Predefined presets can't be edited, but can be "customized." Most predefined presets allow changing some options. Adjusting options of a predefined preset will result in a "customized" preset. Both installation commands will ask you if you want to update the customized preset(s) (if any) and lose your adjustments, or to skip those updated by the plugin developer, but customized by you.


REMOVING THE PLUGIN

1 – Open MusicBee. From the menubar > Edit > Edit Preferences > Plugins > Additional Tagging & Reporting Tools > Uninstall.
2 – MusicBee will delete all automatically created files (e.g., settings). You will need to close MusicBee and manually delete file "mb_TagTools.dll" and the subfolders "ru" and "ASR Presets" from "Plugins" folder. The "Plugins" folder is located in MusicBee application folder if you are using the portable version of MusicBee. If using the installer version of MusicBee, it's in the folder "%AppData%\MusicBee".

Unfortunately, no plugin can be uninstalled from Store version of MusicBee at the moment.